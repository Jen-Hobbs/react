import React, {Component} from 'react';

import './App.css';
import Axios from 'axios';


class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      search: 'harry potter',
      books: [],
      searched: 'harry potter',
      loading: true,
      unableToFind: ''
           
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleClick = this.handleClick.bind(this);
  }
  handleSubmit(e){
    e.preventDefault();
    
    this.setState({searched: this.state.search});
    
  }
  handleChange(e){
    const {name, value} = e.target;
    this.setState({[name]: value})
  }
  componentDidUpdate(){
    this.getBooks();
    
  }
  componentDidMount(){
    this.getBooks();
    
  }
  handleClick(e){
    const {name} = e.target;
    this.setState({[name]: ''});
  }
  /**
   * handles get requests based of the searched state. If no items are available sets state of books to empty array
   * Resets searched state.
   */
  getBooks(){
    if(this.state.searched){
      this.setState({loading: true, books: []});
      let searching = 'https://www.googleapis.com/books/v1/volumes?q=' + this.state.searched;
      Axios.get(searching)
      .then((response) =>{
        
        if(response.data.totalItems){
          this.setState({books: response.data.items, loading: false, unableToFind: ''});
        }
        else{
          this.setState({loading: false, unableToFind: this.state.searched});
        }
        
      })
      .catch(()=>{
        this.setState({loading: false, unableToFind: this.state.searched});
        console.log("Get request failed for " + searching);
      });
      this.setState({searched: ''});
    }
  }
  render(){
    return(
      <div className="App">
        
        <form onSubmit={this.handleSubmit}>
          Search:
          <input 
          name="search"
          value={this.state.search}
          onChange={this.handleChange}
          onClick={this.handleClick}
          />
        <button type='submit'>Search</button>
        </form>
        {this.state.loading &&(
          <h1>Loading</h1>
        )}
        {(this.state.books.length === 0 && !this.state.loading) &&(
          <h1>Unable to find books from {this.state.unableToFind}</h1>
        )}
        <ul>
          {this.state.books.map((book)=>{
            return (
              <li key={book.id}>
                <div>
                  {book.volumeInfo.imageLinks && (
                    <img src={book.volumeInfo.imageLinks.thumbnail}/>
                  )}
                  <h2><a href={book.volumeInfo.infoLink}>{book.volumeInfo.title}</a></h2>
                  <p>{book.volumeInfo.description}</p>
                  <ul>
                  {book.volumeInfo.categories &&(
                    book.volumeInfo.categories.map((category)=>{
                      return(
                        <li key={category}>{category}</li>
                      )
                    })
                  )}
                  </ul>
                </div>
                
              </li>
            );
          })}
        </ul>
      </div>
    
    )
  }
}

export default App;
